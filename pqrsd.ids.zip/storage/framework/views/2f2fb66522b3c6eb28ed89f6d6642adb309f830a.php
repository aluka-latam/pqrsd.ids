					<!-- View Custom Notification-->
					<div class="modal fade"  id="addfaq" aria-hidden="true">
						<div class="modal-dialog  modal-lg" role="document">
							<div class="modal-content">
								<div class="modal-header">
									<h5 class="modal-title"></h5>
									<button  class="close" data-bs-dismiss="modal"  aria-label="Close">
										<span aria-hidden="true">×</span>
									</button>
								</div>
								<div class="modal-body">
									<h3 id="mailsubject"></h3>
									<p id="mailtest"></p>
								</div>
								
							</div>
						</div>
					</div>
					<!-- View Custom Notification  --><?php /**PATH C:\laragon\www\uhelp\resources\views/admin/custom-notification/model.blade.php ENDPATH**/ ?>