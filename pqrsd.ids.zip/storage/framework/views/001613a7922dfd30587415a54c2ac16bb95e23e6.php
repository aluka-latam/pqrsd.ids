											<!--Vertical Menu-->
											<div class="col-xl-3">
												<div class="card">
													<div class="card-body text-center item-user">
														<div class="profile-pic">
															<div class="profile-pic-img">
																<span class="bg-success dots" data-bs-toggle="tooltip" data-placement="top" title=""
																	data-bs-original-title="online"></span>
																<?php if(Auth::guard('customer')->user()->image == null): ?>

																<img src="<?php echo e(asset('uploads/profile/user-profile.png')); ?>" class="brround avatar-xxl" alt="default">
																<?php else: ?>

																<img src="<?php echo e(asset('uploads/profile/'.Auth::user()->image)); ?>" class="brround avatar-xxl"
																	alt="<?php echo e(Auth::guard('customer')->user()->image); ?>">
																<?php endif; ?>

															</div>
															<a href="#" class="text-dark">
																<h5 class="mt-3 mb-1 font-weight-semibold2"><?php echo e(Auth::guard('customer')->user()->username); ?></h5>

															</a>
															<small class="text-muted "><?php echo e(Auth::guard('customer')->user()->email); ?></small>
														</div>
														<div class="btn-list">
															<?php if(Auth::user()->image != null): ?>

															<a href="javascript:void(0)" class="btn btn-light mt-3"
																data-id="<?php echo e(Auth::guard('customer')->id()); ?>" onclick="deletePost(event.target)">Delete Photo</a>
															<?php endif; ?>
															
														</div>
													</div>
													<div class="support-sidebar">
														<ul class="side-menu custom-ul">
															<li>
																<a class="side-menu__item" href="<?php echo e(route('client.dashboard')); ?>">
																		<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><g><rect fill="none" height="24" width="24"/></g><g><g><g><path d="M3,3v8h8V3H3z M9,9H5V5h4V9z M3,13v8h8v-8H3z M9,19H5v-4h4V19z M13,3v8h8V3H13z M19,9h-4V5h4V9z M13,13v8h8v-8H13z M19,19h-4v-4h4V19z"/></g></g></g></svg><span class="side-menu__label"><?php echo e(trans('langconvert.menu.dashboard')); ?></span></a>
															</li>
															<li>
																<a class="side-menu__item" href="<?php echo e(route('client.profile')); ?>">
																		<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><g><path d="M0,0h24v24H0V0z" fill="none"/></g><g><g><path d="M4,18v-0.65c0-0.34,0.16-0.66,0.41-0.81C6.1,15.53,8.03,15,10,15c0.03,0,0.05,0,0.08,0.01c0.1-0.7,0.3-1.37,0.59-1.98 C10.45,13.01,10.23,13,10,13c-2.42,0-4.68,0.67-6.61,1.82C2.51,15.34,2,16.32,2,17.35V20h9.26c-0.42-0.6-0.75-1.28-0.97-2H4z"/><path d="M10,12c2.21,0,4-1.79,4-4s-1.79-4-4-4C7.79,4,6,5.79,6,8S7.79,12,10,12z M10,6c1.1,0,2,0.9,2,2s-0.9,2-2,2 c-1.1,0-2-0.9-2-2S8.9,6,10,6z"/><path d="M20.75,16c0-0.22-0.03-0.42-0.06-0.63l1.14-1.01l-1-1.73l-1.45,0.49c-0.32-0.27-0.68-0.48-1.08-0.63L18,11h-2l-0.3,1.49 c-0.4,0.15-0.76,0.36-1.08,0.63l-1.45-0.49l-1,1.73l1.14,1.01c-0.03,0.21-0.06,0.41-0.06,0.63s0.03,0.42,0.06,0.63l-1.14,1.01 l1,1.73l1.45-0.49c0.32,0.27,0.68,0.48,1.08,0.63L16,21h2l0.3-1.49c0.4-0.15,0.76-0.36,1.08-0.63l1.45,0.49l1-1.73l-1.14-1.01 C20.72,16.42,20.75,16.22,20.75,16z M17,18c-1.1,0-2-0.9-2-2s0.9-2,2-2s2,0.9,2,2S18.1,18,17,18z"/></g></g></svg><span class="side-menu__label"><?php echo e(trans('langconvert.admindashboard.editprofile')); ?></span></a>
															</li>
															<li>
																<a class="side-menu__item" href="<?php echo e(route('client.ticket')); ?>">
																		<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><g><rect fill="none" height="24" width="24"/></g><g><g/><g><path d="M17,19.22H5V7h7V5H5C3.9,5,3,5.9,3,7v12c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2v-7h-2V19.22z"/><path d="M19,2h-2v3h-3c0.01,0.01,0,2,0,2h3v2.99c0.01,0.01,2,0,2,0V7h3V5h-3V2z"/><rect height="2" width="8" x="7" y="9"/><polygon points="7,12 7,14 15,14 15,12 12,12"/><rect height="2" width="8" x="7" y="15"/></g></g></svg><span class="side-menu__label"><?php echo e(trans('langconvert.adminmenu.createticket')); ?>

																		</span></a>
															</li>
															<?php if(Auth::guard('customer')->check()): ?>
																<form id="logout-form" action="<?php echo e(route('client.logout')); ?>" method="POST">
																		<?php echo csrf_field(); ?>
					
																		<button type="submit" class="dropdown-item d-flex">
																			<i class="feather feather-power me-3 fs-16 my-auto"></i>
																		<div class="mt-1"><?php echo e(trans('langconvert.menu.logout')); ?></div>
																		</button>
																</form>
															<?php endif; ?>
															
														</ul>
													</div>
												</div>
											</div>
											<!--Vertical Menu-->

<?php /**PATH C:\laragon\www\uhelp\resources\views/includes/user/verticalmenu.blade.php ENDPATH**/ ?>