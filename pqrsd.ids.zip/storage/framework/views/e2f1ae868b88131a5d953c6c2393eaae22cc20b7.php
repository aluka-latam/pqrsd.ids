

<?php $__env->startSection('styles'); ?>

		<!-- INTERNAL owl-carousel css-->
		<link href="<?php echo e(asset('assets/plugins/owl-carousel/owl-carousel.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

							<!--Banner Section-->
							<section>
								<div class="banner-1 cover-image sptb-tab bg-background-support" data-bs-image-src="<?php echo e(asset('assets/images/photos/banner2.jpg')); ?>" style="height: 1000px;">
									<div class="header-text content-text mb-0">
										<div class="container">
											<div class="text-center text-white mb-7 mt-9">
												<h1 class="mb-2"><?php echo e($title->searchtitle); ?></h1>
												<p class="fs-18"><?php echo e($title->searchsub); ?></p>
											</div>
											<div class="row">
												<div class="col-xl-7 col-lg-12 col-md-12 d-block mx-auto">
													<div class="search-background p-0">
														<input type="text" class="form-control input-lg" name="search_name" id="search_name"  placeholder="Ingresa el radicado completo...">
														<button class="btn"><i class="fe fe-search"></i></button>

														<div id="searchList">
															
														</div>
													</div>
													<?php echo csrf_field(); ?>

												</div>
											</div>
										</div>
									</div>
								</div>
							</section>
							<!--Banner Section-->

							<!--Feature Box Section-->
							
							<!--Feature Box Section-->
						
						

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

		<!--INTERNAL Owl-carousel js -->
		<script src="<?php echo e(asset('assets/plugins/owl-carousel/owl-carousel.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Index js-->
		<script src="<?php echo e(asset('assets/js/support/support-landing.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Index js-->
		<script src="<?php echo e(asset('assets/plugins/jquery/jquery-ui.js')); ?>?v=<?php echo time(); ?>"></script>

		<script type="text/javascript">
			"use strict";
			
			(function($){

				// close the data search
				document.querySelector('.page-main').addEventListener('click', ()=>{ 
					$('#searchList').fadeOut();
					$('#searchList').html(''); 
				});

				// search the data
				$('#search_name').keyup(function () {

					var data = $(this).val();
					if (data != '') {
						var _token = $('input[name="_token"]').val();
						$.ajax({
							url: "<?php echo e(url('/search')); ?>",
							method: "POST",
							data: {data: data, _token: _token},

							dataType:"json",

							success: function (data) {
								//console.log(data);
								$('#searchList').fadeIn();
								$('#searchList').html(data);
								const ps3 = new PerfectScrollbar('.sprukohomesearch', {
									useBothWheelAxes:true,
									suppressScrollX:true,
								});
							},
							error: function (data) {
								console.log(data);
							}
						});
					}
				});

			})(jQuery);

		</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.masterids', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\uhelp\resources\views/home.blade.php ENDPATH**/ ?>