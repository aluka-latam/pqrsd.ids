

		<?php $__env->startSection('styles'); ?>

		<!-- INTERNAL Data table css -->
		<link href="<?php echo e(asset('assets/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />
		<link href="<?php echo e(asset('assets/plugins/datatable/responsive.bootstrap5.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />

		<!-- INTERNAL Sweet-Alert css -->
		<link href="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />

		<?php $__env->stopSection(); ?>

							<?php $__env->startSection('content'); ?>

							<!--Page header-->
							<div class="page-header d-xl-flex d-block">
								<div class="page-leftheader">
									<h4 class="page-title"><span class="font-weight-normal text-muted ms-2"><?php echo e(trans('langconvert.adminmenu.testimonial')); ?></span></h4>
								</div>
							</div>
							<!--End Page header-->

							<!--Testimonial Section-->
							<div class="col-xl-12 col-lg-12 col-md-12">
								<div class="card ">
									<form method="POST" action="<?php echo e(url('/admin/testimonial')); ?>" enctype="multipart/form-data">
										<?php echo csrf_field(); ?>

										<?php echo view('honeypot::honeypotFormFields'); ?>

										<div class="card-header border-0 d-sm-max-flex">
											<h4 class="card-title"><?php echo e(trans('langconvert.admindashboard.testimonialsection')); ?></h4>
											<div class="card-options card-header-styles mt-sm-max-2">
												<small class="me-1 mt-1"><?php echo e(trans('langconvert.admindashboard.sectionhide')); ?></small>
												<div class="float-end mt-0">
													<div class="switch-toggle">
														<a class="onoffswitch2">
															<input type="checkbox"  name="testimonialcheck" id="testimonialchecks" class=" toggle-class onoffswitch2-checkbox" value="on" <?php if($basic->testimonialcheck == 'on'): ?>  checked=""  <?php endif; ?>>
															<label for="testimonialchecks" class="toggle-class onoffswitch2-label" ></label>
														</a>
													</div>
												</div>
											</div>
										</div>
										<div class="card-body" >
											<div class="row">
												<div class="col-sm-12 col-md-12">
													<input type="hidden" class="form-control " name="id" value="<?php echo e($basic->id); ?>">
													<div class="form-group">
														<label class="form-label"><?php echo e(trans('langconvert.admindashboard.title')); ?> <span class="text-red">*</span></label>
														<input type="text" class="form-control <?php $__errorArgs = ['testimonialtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="testimonialtitle" value="<?php echo e($basic->testimonialtitle); ?>">
														<?php $__errorArgs = ['testimonialtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

													</div>
												</div>
												<div class="col-sm-12 col-md-12">
													<div class="form-group">
														<label class="form-label"><?php echo e(trans('langconvert.admindashboard.subtitle')); ?></label>
														<input type="text" class="form-control <?php $__errorArgs = ['testimonialsub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="testimonialsub" value="<?php echo e($basic->testimonialsub); ?>">
														<?php $__errorArgs = ['testimonialsub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

													</div>
												</div>
											</div>
										</div>
										<div class="col-md-12 card-footer ">
											<div class="form-group float-end">
												<input type="submit" class="btn btn-secondary" value="<?php echo e(trans('langconvert.admindashboard.savechanges')); ?>" onclick="this.disabled=true;this.form.submit();">
											</div>
										</div>
									</form>
								</div>
							</div>
							<!--End Testimonial Section-->

							<!--Testimonial List-->
							<div class="col-xl-12 col-lg-12 col-md-12">
								<div class="card ">
									<div class="card-header border-0 d-sm-max-flex">
										<h4 class="card-title"><?php echo e(trans('langconvert.admindashboard.testimoniallist')); ?></h4>
										<div class="card-options mt-sm-max-2">
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Testimonial Create')): ?>

											<a href="javascript:void(0)" class="btn btn-secondary me-3" id="create-new-testimonial"><?php echo e(trans('langconvert.admindashboard.addtestimonial')); ?></a>
											<?php endif; ?>

										</div>
									</div>
									<div class="card-body" >
										<div class="table-responsive spruko-delete">
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Testimonial Delete')): ?>

											<button id="massdeletenotify" class="btn btn-outline-light btn-sm mb-4 data-table-btn"><i class="fe fe-trash"></i> <?php echo e(trans('langconvert.admindashboard.delete')); ?></button>
											<?php endif; ?>

											<table class="table table-vcenter text-nowrap table-bordered table-striped ticketdeleterow w-100" id="support-articlelists">
												<thead>
													<tr>
														<th  width="10"><?php echo e(trans('langconvert.admindashboard.id')); ?></th>
														<th  width="10"><?php echo e(trans('langconvert.admindashboard.slNo')); ?></th>
														<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Testimonial Delete')): ?>

														<th width="10" >
															<input type="checkbox"  id="customCheckAll">
															<label  for="customCheckAll"></label>
														</th>
														<?php endif; ?>
														<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('Testimonial Delete')): ?>

														<th width="10" >
															<input type="checkbox"  id="customCheckAll" disabled>
															<label  for="customCheckAll"></label>
														</th>
														<?php endif; ?>

														<th ><?php echo e(trans('langconvert.admindashboard.name')); ?></th>
														<th ><?php echo e(trans('langconvert.admindashboard.designation')); ?></th>
														<th ><?php echo e(trans('langconvert.admindashboard.actions')); ?></th>
													</tr>
												</thead>
											</table>
										</div>
									</div>
								</div>
							</div>
							<!--End Testimonial List-->

							<?php $__env->stopSection(); ?>
	<?php $__env->startSection('modal'); ?>

   	<?php echo $__env->make('admin.testimonial.model', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php $__env->stopSection(); ?>

		<?php $__env->startSection('scripts'); ?>

		<!-- INTERNAL Vertical-scroll js-->
		<script src="<?php echo e(asset('assets/plugins/vertical-scroll/jquery.bootstrap.newsbox.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Data tables -->
		<script src="<?php echo e(asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/datatable/js/dataTables.bootstrap5.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/datatable/dataTables.responsive.min.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/datatable/responsive.bootstrap5.min.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/datatable/datatablebutton.min.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/datatable/buttonbootstrap.min.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Index js-->
		<script src="<?php echo e(asset('assets/js/support/support-sidemenu.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Sweet-Alert js-->
		<script src="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert.min.js')); ?>?v=<?php echo time(); ?>"></script>

        <script type="text/javascript">

			"use strict";

			(function($)  {

				// Variables
				var SITEURL = '<?php echo e(url('')); ?>';

				// Csrf Field
				$.ajaxSetup({
					headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					}
				});

				// Datatable
				$('#support-articlelists').dataTable({

					processing: true,
					serverSide: true,
					ajax: {
					url: "<?php echo e(url('/admin/testimonial')); ?>"
					},
					columns: [
						{data: 'id', name: 'id', 'visible': false},
						{data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false,searchable: false},
						{data: 'checkbox', name: 'checkbox', orderable: false,searchable: false},
						{data: 'name', name: 'name' },
						{data: 'designation', name: 'designation' },
						{data: 'action', name: 'action', orderable: false},
					],
					order:[],
					responsive: true,
					drawCallback: function () {
						var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
						var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
							return new bootstrap.Tooltip(tooltipTriggerEl)
						});
						$('.form-select').select2({
							minimumResultsForSearch: Infinity,
							width: '100%'
						});
						$('#customCheckAll').prop('checked', false);
						$('.checkall').on('click', function(){
							if($('.checkall:checked').length == $('.checkall').length){
								$('#customCheckAll').prop('checked', true);
							}else{
								$('#customCheckAll').prop('checked', false);
							}
						});
					},
				});

				/*  When user click add testimonial button */
				$('#create-new-testimonial').on('click', function () {
					$('#btnsave').val("create-product");
					$('#testimonial_id').val('');
					$('#testimonial_form').trigger("reset");
					$('.modal-title').html("<?php echo e(trans('langconvert.admindashboard.addnewtestimonial')); ?>");
					$('#addtestimonial').modal('show');
					$('#image-preview').attr('src', '<?php echo e(asset('assets/images/imagepreview/displayimage.png')); ?>');
				});

				/* When click edit testimonial */
				$('body').on('click', '.edit-testimonial', function () {
					var testimonial_id = $(this).data('id');
					$.get('testimonial/' + testimonial_id , function (data) {
						$('#nameError').html('');
						$('#descriptionError').html('');
						$('#designationError').html('');
						$('#imageError').html('');

						$('.modal-title').html("<?php echo e(trans('langconvert.admindashboard.edittestimonial')); ?>");
						$('#btnsave').val("edit-testimonial");
						$('#addtestimonial').modal('show');
						$('#testimonial_id').val(data.id);
						$('#name').val(data.name);
						$('#designation').val(data.designation);
						$('#description').val(data.description);
						$('#image-preview').attr('alt', 'No image available');
						if(data.image){
							$('#image-preview').attr('src', SITEURL +'/uploads/testimonial/'+data.image);
							$('#image').attr('src', SITEURL +'/uploads/testimonial/'+data.image);
						}
					})
				});

				// Delete Testimonial
				$('body').on('click', '#delete-testimonial', function () {
					var _id = $(this).data("id");
					swal({
						title: `<?php echo e(trans('langconvert.admindashboard.wanttocontinue')); ?>`,
						text: "<?php echo e(trans('langconvert.admindashboard.eraserecordspermanently')); ?>",
						icon: "warning",
						buttons: true,
						dangerMode: true,
					})
					.then((willDelete) => {
						if (willDelete) {
							$.ajax({
								type: "get",
								url: SITEURL + "/admin/testimonial/delete/"+_id,
								success: function (data) {
								var oTable = $('#support-articlelists').dataTable();
								oTable.fnDraw(false);
								toastr.error(data.error);
								},
								error: function (data) {
								console.log('Error:', data);
								}
							});
						}
					});
				});

				// Mass Delete Testimonial
				$('body').on('click', '#massdeletenotify', function () {
					var id = [];
					$('.checkall:checked').each(function(){
						id.push($(this).val());
					});
					if(id.length > 0){
						swal({
							title: `<?php echo e(trans('langconvert.admindashboard.wanttocontinue')); ?>`,
							text: "<?php echo e(trans('langconvert.admindashboard.eraserecordspermanently')); ?>",
							icon: "warning",
							buttons: true,
							dangerMode: true,
						})
						.then((willDelete) => {
							if (willDelete) {
								$.ajax({
									url:"<?php echo e(route('testimonial.deleteall')); ?>",
									method:"post",
									data:{id:id},
									success:function(data)
									{
										$('#support-articlelists').DataTable().ajax.reload();
										toastr.error(data.error);
													
									},
									error:function(data){
										console.log(data);
									}
								});
							}
						});			
					}else{
						toastr.error('<?php echo e(trans('langconvert.functions.checkboxselect')); ?>');
					}
					

				});

				// Testimonial submit form
				$('body').on('submit', '#testimonial_form', function (e) {
					e.preventDefault();
					var actionType = $('#btnsave').val();
					var fewSeconds = 2;
					$('#btnsave').html('Sending..');
					$('#btnsave').prop('disabled', true);
						setTimeout(function(){
							$('#btnsave').prop('disabled', false);
						}, fewSeconds*1000);
					var formData = new FormData(this);
					$.ajax({
					type:'POST',
					url: SITEURL + "/admin/testimonial/create",
					data: formData,
					cache:false,
					contentType: false,
					processData: false,

					success: (data) => {
						$('#nameError').html('');
						$('#descriptionError').html('');
						$('#designationError').html('');
						$('#imageError').html('');

						$('#testimonial_form').trigger("reset");
						$('#addtestimonial').modal('hide');
						$('#btnsave').html('Save Changes');
						var oTable = $('#support-articlelists').dataTable();
						oTable.fnDraw(false);
						toastr.success(data.success);
					},
					error: function(data){
						
						$('#nameError').html('');
						$('#descriptionError').html('');
						$('#designationError').html('');
						$('#imageError').html('');
						$('#nameError').html(data.responseJSON.errors.name);
						$('#descriptionError').html(data.responseJSON.errors.description);
						$('#designationError').html(data.responseJSON.errors.designation);
						$('#imageError').html(data.responseJSON.errors.image);
						$('#btnsave').html('Save Changes');
					}
					});
				});
				
				// Checkbox checkall
				$('#customCheckAll').on('click', function() {
					$('.checkall').prop('checked', this.checked);
				});

			})(jQuery);
		</script>

		<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\uhelp\resources\views/admin/testimonial/index.blade.php ENDPATH**/ ?>