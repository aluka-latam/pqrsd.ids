


								<?php $__env->startSection('content'); ?>

								<!-- Section -->
								
								<!-- Section -->

								<!--Profile Page -->
								<section>
									<div class="cover-image sptb">
										<div class="container ">
											<div class="row">
												<?php echo $__env->make('includes.user.verticalmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

												<div class="col-xl-9">
													<div class="card">
														<div class="card-header border-0">
															<h4 class="card-title"><?php echo e(trans('langconvert.admindashboard.profiledetails')); ?></h4>
														</div>
														<div class="card-body">
															<form method="POST" action="<?php echo e(route('client.profilesetup')); ?>" enctype="multipart/form-data">
																<?php echo csrf_field(); ?>

																<?php echo view('honeypot::honeypotFormFields'); ?>

																<div class="row">
																	
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.firstname')); ?><span class="text-red">*</span></label>
																			<input type="text"
																				class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																				name="firstname" value="<?php echo e(old('firstname',Auth::guard('customer')->user()->firstname)); ?>">
																			<?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																			<span class="invalid-feedback" role="alert">
																				<strong><?php echo e($message); ?></strong>
																			</span>
																			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.lastname')); ?><span class="text-red">*</span></label>
																			<input type="text"
																				class="form-control <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																				name="lastname" value="<?php echo e(old('lastname', Auth::guard('customer')->user()->lastname)); ?>">
																			<?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																			<span class="invalid-feedback" role="alert">
																				<strong><?php echo e($message); ?></strong>
																			</span>
																			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.tiposolicitante')); ?><span class="text-red">*</span></label>
																			<select name="tiposolicitante" id="input-date_format" class="form-control select2 select2-show-search" required>
																			
																				<option value="Persona Natural" <?php echo e(Auth::guard('customer')->user()->tiposolicitante == 'Persona Natural' ? 'selected' : ''); ?>>Persona Natural</option>
																				<option value="Persona Jurídica" <?php echo e(Auth::guard('customer')->user()->tiposolicitante == 'Persona Jurídica' ? 'selected' : ''); ?>>Persona Jurídica</option>
																				
						
																			</select>
																			<?php $__errorArgs = ['tiposolicitante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																			<span class="invalid-feedback" role="alert">
																				<strong><?php echo e($message); ?></strong>
																			</span>
																			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.emailsend')); ?><span class="text-red">*</span></label>
																			<select name="emailsend" id="input-date_format" class="form-control select2 select2-show-search" required>
																			
																				<option value="1" <?php echo e(Auth::guard('customer')->user()->emailsend == true ? 'selected' : ''); ?>>Correo electrónico</option>
																				<option value="0" <?php echo e(Auth::guard('customer')->user()->emailsend == false ? 'selected' : ''); ?>>Fisicamente a su dirección</option>
																				
																			</select>
																			<?php $__errorArgs = ['emailsend'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																			<span class="invalid-feedback" role="alert">
																				<strong><?php echo e($message); ?></strong>
																			</span>
																			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.tipodocumento')); ?><span class="text-red">*</span></label>
																			<select name="tipodocumento" id="input-date_format" class="form-control select2 select2-show-search" required>
																				<option>Seleccione porfavor</option>
																				<option value="Cédula de ciudadania" <?php echo e(Auth::guard('customer')->user()->tipodocumento == 'Cédula de ciudadania' ? 'selected' : ''); ?>>Cédula de ciudadania</option>
																				<option value="Cédula de extrangeria" <?php echo e(Auth::guard('customer')->user()->tipodocumento == 'Cédula de extrangeria' ? 'selected' : ''); ?>>Cédula de extrangeria</option>
																				<option value="Pasaporte" <?php echo e(Auth::guard('customer')->user()->tipodocumento == 'Pasaporte' ? 'selected' : ''); ?>>Pasaporte</option>
																				<option value="Registro civil" <?php echo e(Auth::guard('customer')->user()->tipodocumento == 'Registro civil' ? 'selected' : ''); ?>>Registro civil</option>
																				<option value="Tarjeta de identidad" <?php echo e(Auth::guard('customer')->user()->tipodocumento == 'Tarjeta de identidad' ? 'selected' : ''); ?>>Tarjeta de identidad</option>
																				<option value="Otros" <?php echo e(Auth::guard('customer')->user()->tipodocumento == 'Otros' ? 'selected' : ''); ?>>Otros</option>																				
						
																			</select>
																			<?php $__errorArgs = ['tipodocumento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																			<span class="invalid-feedback" role="alert">
																				<strong><?php echo e($message); ?></strong>
																			</span>
																			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.documento')); ?><span class="text-red">*</span></label>
																			<input type="text"
																				class="form-control <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																				name="documento" value="<?php echo e(old('documento', Auth::guard('customer')->user()->documento)); ?>">
																			<?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																			<span class="invalid-feedback" role="alert">
																				<strong><?php echo e($message); ?></strong>
																			</span>
																			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.razonsocial')); ?><span class="text-red"></span></label>
																			<input type="text"
																				class="form-control <?php $__errorArgs = ['razonsocial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																				name="razonsocial" value="<?php echo e(old('razonsocial', Auth::guard('customer')->user()->razonsocial)); ?>">
																			<?php $__errorArgs = ['razonsocial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																			<span class="invalid-feedback" role="alert">
																				<strong><?php echo e($message); ?></strong>
																			</span>
																			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.nit')); ?><span class="text-red"></span></label>
																			<input type="text"
																				class="form-control <?php $__errorArgs = ['nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																				name="nit" value="<?php echo e(old('nit', Auth::guard('customer')->user()->nit)); ?>">
																			<?php $__errorArgs = ['nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																			<span class="invalid-feedback" role="alert">
																				<strong><?php echo e($message); ?></strong>
																			</span>
																			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.emailaddress')); ?></label>
																			<input type="email" class="form-control"
																				Value="<?php echo e(Auth::guard('customer')->user()->email); ?>" readonly>

																		</div>
																	</div>
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.mobilenumber')); ?></label>
																			<input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																				value="<?php echo e(old('phone', Auth::guard('customer')->user()->phone)); ?>" name="phone">
																				<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																				<span class="invalid-feedback" role="alert">
																					<strong><?php echo e($message); ?></strong>
																				</span>
																				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	<div class="col-sm-6 col-md-6">
																		<div class="form-group">
																			<label class="form-label"><?php echo e(trans('langconvert.admindashboard.municipio')); ?><span class="text-red"></span></label>
																			<input type="text"
																				class="form-control <?php $__errorArgs = ['municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																				name="municipio" value="<?php echo e(old('nit', Auth::guard('customer')->user()->municipio)); ?>">
																			<?php $__errorArgs = ['municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

																			<span class="invalid-feedback" role="alert">
																				<strong><?php echo e($message); ?></strong>
																			</span>
																			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

																		</div>
																	</div>
																	
																	
																	

																	<div class="col-md-12 card-footer ">
																		<div class="form-group">
																			<input type="submit" class="btn btn-secondary float-end " value="<?php echo e(trans('langconvert.admindashboard.savechanges')); ?>"
																				onclick="this.disabled=true;this.form.submit();">
																		</div>
																	</div>
																</div>
															</form>
														</div>
													</div>
													
													
													<?php echo $__env->make('user.auth.passwords.changepassword', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

													<div class="card">
														<div class="card-header">
															<div class="card-title"><?php echo e(trans('langconvert.userdashboard.deleteaccount')); ?></div>
														</div>
														<div class="card-body">
															<p><?php echo e(trans('langconvert.userdashboard.deleteaccountcontent')); ?></p>
															<label class="custom-control form-checkbox">
																<input type="checkbox" class="custom-control-input " value="agreed" name="agree_terms" id="sprukocheck">
																<span class="custom-control-label"><?php echo e(trans('langconvert.userdashboard.iagree')); ?> <a href="<?php echo e(setting('terms_url')); ?>" class="text-primary"> <?php echo e(trans('langconvert.userdashboard.termsservices')); ?></a> </span>
															</label>
														</div>
														<div class="card-footer text-end">
															<button  class="btn btn-danger my-1" data-id="<?php echo e(Auth::guard('customer')->id()); ?>" id="accountdelete"><?php echo e(trans('langconvert.userdashboard.deleteaccount')); ?></button>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</section>
								<!--Profile Page -->

								<?php $__env->stopSection(); ?>

		<?php $__env->startSection('scripts'); ?>


		<!-- INTERNAL Vertical-scroll js-->
		<script src="<?php echo e(asset('assets/plugins/vertical-scroll/jquery.bootstrap.newsbox.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Index js-->
		<script src="<?php echo e(asset('assets/js/support/support-sidemenu.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/js/select2.js')); ?>?v=<?php echo time(); ?>"></script>


		<script type="text/javascript">
            "use strict";
			
			(function($){

				// Variables
				var SITEURL = '<?php echo e(url('')); ?>';

				// Csrf Field
				$.ajaxSetup({
					headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					}
				});	

				// Profile Account Delete
				$('body').on('click', '#accountdelete', function () {
					var _id = $(this).data("id");

					swal({
						title: `<?php echo e(trans('langconvert.userdashboard.warningaccount')); ?>`,
						text: "<?php echo e(trans('langconvert.userdashboard.permanentlydelete')); ?>",
						icon: "warning",
						buttons: true,
						dangerMode: true,
					})
					.then((willDelete) => {
						if (willDelete) {
							$.ajax({
								type: "post",
								url: SITEURL + "/customer/deleteaccount/"+_id,
								success: function (data) {
								location.reload();
								toastr.error(data.error);
								},
								error: function (data) {
								console.log('Error:', data);
								}
							});
						}
					});
				});	

				// Switch to dark mode js
				$('.sprukolayouts').on('change', function() {
					var dark = $('#darkmode').prop('checked') == true ? '1' : '';
					var cust_id = $(this).data('id');
					console.log(dark);
					$.ajax({
						type: "POST",
						dataType: "json",
						url: '<?php echo e(url('/customer/custsettings')); ?>',
						data: {
							'dark': dark,
						 	'cust_id': cust_id
						},
						success: function(data){
							location.reload();
							toastr.success('<?php echo e(trans('langconvert.functions.updatecommon')); ?>');
						}
					});
				});	

			})(jQuery);

			// If no tick in check box in disable in the delete button
			var checker = document.getElementById('sprukocheck');
			var sendbtn = document.getElementById('accountdelete');
			if(!this.checked){
				sendbtn.style.pointerEvents = "auto";
					sendbtn.style.cursor = "not-allowed";
				}else{
					sendbtn.style.cursor = "pointer";
				}
			sendbtn.disabled = !this.checked;
		
			checker.onchange = function() {
				
				sendbtn.disabled = !this.checked;
				if(!this.checked){
					sendbtn.style.pointerEvents = "auto";
					sendbtn.style.cursor = "not-allowed";
				}else{
					sendbtn.style.cursor = "pointer";
				}
			};
			
		</script>

		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.usermaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\uhelp\resources\views/user/profile/userprofile.blade.php ENDPATH**/ ?>