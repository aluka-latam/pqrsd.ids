

		<?php $__env->startSection('styles'); ?>

		<!-- INTERNAl Summernote css -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/summernote/summernote.css')); ?>?v=<?php echo time(); ?>">

		<!-- INTERNAl Dropzone css -->
		<link href="<?php echo e(asset('assets/plugins/dropzone/dropzone.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />

		<!-- GALLERY CSS -->
		<link href="<?php echo e(asset('assets/plugins/simplelightbox/simplelightbox.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet">

		<?php $__env->stopSection(); ?>

							<?php $__env->startSection('content'); ?>

							<!-- Section -->
							
							<!-- Section -->

							<!--Ticket Show-->
							<section>
								<div class="cover-image sptb">
									<div class="container ">
										<div class="row">
										
											<div class="col-xl-4">
												<div id="scroll-stickybar" class="w-100 pos-sticky-scroll">
													<div class="card">
														<div class="card-body text-center item-user">
															<div class="profile-pic">
																<div class="profile-pic-img mb-2">
																	<span class="bg-success dots" data-bs-toggle="tooltip" data-placement="top" title=""
																		data-bs-original-title="online"></span>
																	<?php if(Auth::user()->image == null): ?>

																	<img src="<?php echo e(asset('uploads/profile/user-profile.png')); ?>" class="brround avatar-xxl"
																		alt="default">
																	<?php else: ?>

																	<img class="brround avatar-xxl" alt="<?php echo e(Auth::user()->image); ?>"
																		src="<?php echo e(asset('uploads/profile/'.Auth::user()->image)); ?>">
																	<?php endif; ?>

																</div>
																<a href="#" class="text-dark">
																	<h5 class="mb-1 font-weight-semibold2"><?php echo e(Auth::user()->username); ?></h5>
																</a>
																<small class="text-muted "><?php echo e(Auth::user()->email); ?></small>
															</div>
														</div>
														<div class="support-sidebar">
															<ul class="side-menu custom-ul">
																<li>
																	<a class="side-menu__item" href="<?php echo e(route('client.dashboard')); ?>">
																			<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><g><rect fill="none" height="24" width="24"/></g><g><g><g><path d="M3,3v8h8V3H3z M9,9H5V5h4V9z M3,13v8h8v-8H3z M9,19H5v-4h4V19z M13,3v8h8V3H13z M19,9h-4V5h4V9z M13,13v8h8v-8H13z M19,19h-4v-4h4V19z"/></g></g></g></svg><span class="side-menu__label"><?php echo e(trans('langconvert.menu.dashboard')); ?></span></a>
																</li>
																<li>
																	<a class="side-menu__item" href="<?php echo e(route('client.profile')); ?>">
																			<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><g><path d="M0,0h24v24H0V0z" fill="none"/></g><g><g><path d="M4,18v-0.65c0-0.34,0.16-0.66,0.41-0.81C6.1,15.53,8.03,15,10,15c0.03,0,0.05,0,0.08,0.01c0.1-0.7,0.3-1.37,0.59-1.98 C10.45,13.01,10.23,13,10,13c-2.42,0-4.68,0.67-6.61,1.82C2.51,15.34,2,16.32,2,17.35V20h9.26c-0.42-0.6-0.75-1.28-0.97-2H4z"/><path d="M10,12c2.21,0,4-1.79,4-4s-1.79-4-4-4C7.79,4,6,5.79,6,8S7.79,12,10,12z M10,6c1.1,0,2,0.9,2,2s-0.9,2-2,2 c-1.1,0-2-0.9-2-2S8.9,6,10,6z"/><path d="M20.75,16c0-0.22-0.03-0.42-0.06-0.63l1.14-1.01l-1-1.73l-1.45,0.49c-0.32-0.27-0.68-0.48-1.08-0.63L18,11h-2l-0.3,1.49 c-0.4,0.15-0.76,0.36-1.08,0.63l-1.45-0.49l-1,1.73l1.14,1.01c-0.03,0.21-0.06,0.41-0.06,0.63s0.03,0.42,0.06,0.63l-1.14,1.01 l1,1.73l1.45-0.49c0.32,0.27,0.68,0.48,1.08,0.63L16,21h2l0.3-1.49c0.4-0.15,0.76-0.36,1.08-0.63l1.45,0.49l1-1.73l-1.14-1.01 C20.72,16.42,20.75,16.22,20.75,16z M17,18c-1.1,0-2-0.9-2-2s0.9-2,2-2s2,0.9,2,2S18.1,18,17,18z"/></g></g></svg><span class="side-menu__label"><?php echo e(trans('langconvert.admindashboard.editprofile')); ?></span></a>
																</li>
																<li>
																	<a class="side-menu__item" href="<?php echo e(route('client.ticket')); ?>">
																			<svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" enable-background="new 0 0 24 24" height="24px" viewBox="0 0 24 24" width="24px" fill="#000000"><g><rect fill="none" height="24" width="24"/></g><g><g/><g><path d="M17,19.22H5V7h7V5H5C3.9,5,3,5.9,3,7v12c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2v-7h-2V19.22z"/><path d="M19,2h-2v3h-3c0.01,0.01,0,2,0,2h3v2.99c0.01,0.01,2,0,2,0V7h3V5h-3V2z"/><rect height="2" width="8" x="7" y="9"/><polygon points="7,12 7,14 15,14 15,12 12,12"/><rect height="2" width="8" x="7" y="15"/></g></g></svg><span class="side-menu__label"><?php echo e(trans('langconvert.adminmenu.createticket')); ?>

																			</span></a>
																</li>
																<?php if(Auth::guard('customer')->check()): ?>
																	<form id="logout-form" action="<?php echo e(route('client.logout')); ?>" method="POST">
																			<?php echo csrf_field(); ?>
						
																			<button type="submit" class="dropdown-item d-flex">
																				<i class="feather feather-power me-3 fs-16 my-auto"></i>
																			<div class="mt-1"><?php echo e(trans('langconvert.menu.logout')); ?></div>
																			</button>
																	</form>
																<?php endif; ?>
																
															</ul>
														</div>
													</div>

													

													<div class="card">
														<div class="card-header  border-0">
															<div class="card-title"><?php echo e(trans('langconvert.admindashboard.ticketinformation')); ?></div>
															<input type="hidden" name="" data-id="<?php echo e($ticket->id); ?>" id="ticket">
															<div class="float-end ms-auto"><a href="<?php echo e(route('client.ticket')); ?>" class="btn btn-white btn-sm ms-auto"><i class="fa fa-paper-plane-o me-2 fs-14"></i><?php echo e(trans('langconvert.adminmenu.createticket')); ?></a></div>
														</div>
														<div class="card-body pt-2 px-0 pb-0">
															<div class="table-responsive tr-lastchild">
																<table class="table mb-0 table-information">
																	<tbody>
																		<tr>
																			<td>
																				<span class="w-50"><?php echo e(trans('langconvert.admindashboard.ticketid')); ?></span>
																			</td>
																			<td>:</td>
																			<td>
																				<span class="font-weight-semibold">#<?php echo e($ticket->ticket_id); ?></span>
																			</td>
																		</tr>
																		<tr>
																			<td>
																				<span class="w-50"><?php echo e(trans('langconvert.admindashboard.ticketcategory')); ?></span>
																			</td>
																			<td>:</td>
																			<td>
																				<?php if($ticket->category_id != null): ?>

																				<span class="font-weight-semibold"><?php echo e($ticket->category->name); ?></span>
																				<?php endif; ?>

																			</td>
																		</tr>
																		<?php if($ticket->subcategory != null): ?>
																		<tr>
																			<td>
																				<span class="w-50"><?php echo e(trans('langconvert.newwordslang.ticketsubcategory')); ?></span>
																			</td>
																			<td>:</td>
																			<td>
																				<span class="font-weight-semibold"><?php echo e($ticket->subcategories->subcatlists->subcategoryname); ?></span>
																				
																			</td>
																		</tr>
																		<?php endif; ?>
																		<?php if($ticket->project != null): ?>

																		<tr>
																			<td>
																				<span class="w-50"><?php echo e(trans('langconvert.admindashboard.ticketproject')); ?></span>
																			</td>
																			<td>:</td>
																			<td>
																				<span class="font-weight-semibold"><?php echo e($ticket->project); ?></span>
																			</td>
																		</tr>
																		<?php endif; ?>

																		<tr>
																			<td>
																				<span class="w-50"><?php echo e(trans('langconvert.admindashboard.opendate')); ?></span>
																			</td>
																			<td>:</td>
																			<td>
																				<span class="font-weight-semibold"><?php echo e($ticket->created_at->format(setting('date_format'))); ?></span>
																			</td>
																		</tr>
																		<tr>
																			<td>
																				<span class="w-50"><?php echo e(trans('langconvert.admindashboard.status')); ?></span>
																			</td>
																			<td>:</td>
																			<td>
																				<?php if($ticket->status == "New"): ?>

																				<span class="badge badge-success"><?php echo e($ticket->status); ?></span>
																				<?php elseif($ticket->status == "Re-Open"): ?>

																				<span class="badge badge-teal"><?php echo e($ticket->status); ?></span>
																				<?php elseif($ticket->status == "Inprogress"): ?>

																				<span class="badge badge-info"><?php echo e($ticket->status); ?></span>
																				<?php elseif($ticket->status == "On-Hold"): ?>

																				<span class="badge badge-warning"><?php echo e($ticket->status); ?></span>
																				<?php else: ?>

																				<span class="badge badge-danger"><?php echo e($ticket->status); ?></span>
																				<?php endif; ?>

																			</td>
																		</tr>
																		<?php if($ticket->replystatus != null): ?>

																		<tr>
																			<td>
																				<span class="w-50"><?php echo e(trans('langconvert.admindashboard.replystatus')); ?></span>
																			</td>
																			<td>:</td>
																			<td>
																				<?php if($ticket->replystatus == "Solved"): ?>

																				<span class="badge badge-success"><?php echo e($ticket->replystatus); ?></span>
																				<?php elseif($ticket->replystatus == "Unanswered"): ?>

																				<span class="badge badge-danger-light"><?php echo e($ticket->replystatus); ?></span>
																				<?php elseif($ticket->replystatus == "Waiting for response"): ?>

																				<span class="badge badge-warning"><?php echo e($ticket->replystatus); ?></span>
																				<?php else: ?>
																				<?php endif; ?>

																			</td>
																		</tr>
																		<?php endif; ?>

																	</tbody>
																</table>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div class="col-xl-8">
												<div class="card">
													<div class="card-header border-0 mb-1 d-block">
														<div class="d-sm-flex d-block">
															<div>
																<h4 class="card-title mb-1 fs-22"><?php echo e($ticket->subject); ?> </h4>
															</div>
															<div class="card-options float-sm-end ticket-status">
																<?php if($ticket->status == "New"): ?>
	
																<span class="badge badge-success"><?php echo e($ticket->status); ?></span>
																<?php elseif($ticket->status == "Re-Open"): ?>
	
																<span class="badge badge-teal"><?php echo e($ticket->status); ?></span>
																<?php elseif($ticket->status == "Inprogress"): ?>
	
																<span class="badge badge-info"><?php echo e($ticket->status); ?></span>
																<?php elseif($ticket->status == "On-Hold"): ?>
																
																<span class="badge badge-warning"><?php echo e($ticket->status); ?></span>
																<?php else: ?>
	
																<span class="badge badge-danger"><?php echo e($ticket->status); ?></span>
																<?php endif; ?>
															</div>
														</div>
														<small class="fs-13"><i class="feather feather-clock text-muted me-1"></i><?php echo e(trans('langconvert.admindashboard.lastupdatedon')); ?> <span class="text-muted"><?php echo e($ticket->updated_at->diffForHumans()); ?></span></small>
													</div>
													<div class="card-body readmores pt-2 px-6 mx-1"> 
														<div>
															<span><?php echo $ticket->message; ?></span>
															<div class="row galleryopen">
																<?php $__currentLoopData = $ticket->getMedia('ticket'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticketss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																
																<div class="file-image-1  removespruko<?php echo e($ticketss->id); ?>" id="imageremove<?php echo e($ticketss->id); ?>">
																	<div class="product-image">
																		<a href="<?php echo e($ticketss->getFullUrl()); ?>" class="imageopen">
																			<img src="<?php echo e($ticketss->getFullUrl()); ?>" class="br-5" alt="<?php echo e($ticketss->file_name); ?>">
																		</a>
																	</div>
																	<span class="file-name-1">
																		<?php echo e(Str::limit($ticketss->file_name, 10, $end='.......')); ?>

																	</span>
																</div>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

															</div>
														</div>
													</div>
												</div>
									
									<?php if($ticket->status == 'Closed'): ?>
										<?php if(setting('USER_REOPEN_ISSUE') == 'yes'): ?>
											<?php if(setting('USER_REOPEN_TIME') == '0'): ?>

												<div class="card">
													<form method="POST" action="<?php echo e(url('customer/closed/' .$ticket->ticket_id)); ?>">
														<?php echo csrf_field(); ?>
														<?php echo view('honeypot::honeypotFormFields'); ?>

														<input type="hidden" name="ticket_id" value="<?php echo e($ticket->id); ?>">
														<div class="card-body">
															<p><?php echo e(trans('langconvert.userdashboard.ticketclosedreopen')); ?>

																<input type="submit" class="btn btn-secondary" value="<?php echo e(trans('langconvert.admindashboard.reopen')); ?>"
																	onclick="this.disabled=true;this.form.submit();">
															</p>
														</div>
													</form>
												</div>
											<?php else: ?>
												<?php if($ticket->closing_ticket != null): ?>
												<?php if(now()->format('Y-m-d') <= $ticket->closing_ticket->adddays(setting('USER_REOPEN_TIME'))->format('Y-m-d')): ?>

												<div class="card">
													<form method="POST" action="<?php echo e(url('customer/closed/' .$ticket->ticket_id)); ?>">
														<?php echo csrf_field(); ?>
														<?php echo view('honeypot::honeypotFormFields'); ?>
														
														<input type="hidden" name="ticket_id" value="<?php echo e($ticket->id); ?>">
														<div class="card-body">
															<p><?php echo e(trans('langconvert.userdashboard.ticketclosedreopen')); ?>

																<input type="submit" class="btn btn-secondary" value="<?php echo e(trans('langconvert.admindashboard.reopen')); ?>"
																	onclick="this.disabled=true;this.form.submit();">
															</p>
														</div>
													</form>
												</div>
												<?php endif; ?>
												<?php endif; ?>
											<?php endif; ?>
										<?php endif; ?>
									<?php elseif($ticket->status == 'On-Hold'): ?>
								
												<div class="alert alert-light-warning note" role="alert">
													<p class="m-0"><b><?php echo e(trans('langconvert.admindashboard.note')); ?>:-</b> <?php echo e($ticket->note); ?></p>
												</div>
									<?php else: ?>

												<div class="card">
													<div class="card-header border-0">
														<h4 class="card-title"><?php echo e(trans('langconvert.admindashboard.replyticket')); ?></h4>
													</div>
													<form method="POST" action="<?php echo e(route('client.comment', $ticket->ticket_id)); ?>"
														enctype="multipart/form-data">
														<?php echo csrf_field(); ?>
														<?php echo view('honeypot::honeypotFormFields'); ?>

														<input type="hidden" name="ticket_id" value="<?php echo e($ticket->id); ?>">
														<div class="card-body">
															<textarea class="summernote form-control  <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
																name="comment" rows="6" cols="100" aria-multiline="true"></textarea>
																
															<?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
															<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

															<?php if(setting('USER_FILE_UPLOAD_ENABLE') == 'yes'): ?>

															<div class="form-group mt-3">
																<label class="form-label"><?php echo e(trans('langconvert.admindashboard.uploadimage')); ?></label>
																<div class="file-browser">
																	<div class="needsclick dropzone" id="document-dropzone"></div>
																</div>
																<small class="text-muted"><i><?php echo e(trans('langconvert.admindashboard.filesizenotbe')); ?>

																	<?php echo e(setting('FILE_UPLOAD_MAX')); ?><?php echo e(trans('langconvert.admindashboard.mb')); ?></i></small>
															</div>
															<?php endif; ?>

															<div class="custom-controls-stacked d-md-flex mt-3">
																<label class="form-label mt-1 me-5"><?php echo e(trans('langconvert.admindashboard.status')); ?></label>
																<label class="custom-control form-radio success me-4">
																	<?php if($ticket->status == 'Re-Open'): ?>
																	
																	<input type="radio" class="custom-control-input" name="status"
																		value="Inprogress" <?php echo e($ticket->status == 'Re-Open' ? 'checked' : ''); ?>>
																	<span class="custom-control-label"><?php echo e(trans('langconvert.newwordslang.inprogress')); ?></span>
																	<?php elseif($ticket->status == 'Inprogress'): ?>

																	<input type="radio" class="custom-control-input" name="status"
																		value="<?php echo e($ticket->status); ?>" <?php echo e($ticket->status == 'Inprogress' ? 'checked' :
																	''); ?>>
																	<span class="custom-control-label"><?php echo e(trans('langconvert.newwordslang.leaveascurrent')); ?></span>
																	<?php else: ?>

																	<input type="radio" class="custom-control-input" name="status"
																		value="<?php echo e($ticket->status); ?>" <?php echo e($ticket->status == 'New' ? 'checked' : ''); ?>>
																	<span class="custom-control-label"><?php echo e(trans('langconvert.newwordslang.new')); ?></span>
																	<?php endif; ?>

																</label>
																<label class="custom-control form-radio success">
																	<input type="radio" class="custom-control-input" name="status" value="Closed">
																	<span class="custom-control-label"><?php echo e(trans('langconvert.newwordslang.solved')); ?></span>
																</label>
															</div>
														</div>
														<div class="card-footer">
															<div class="form-group float-end">
																<input type="submit" class="btn btn-secondary" value="<?php echo e(trans('langconvert.admindashboard.reply')); ?>"
																onclick="this.disabled=true;this.form.submit();">
															</div>
														</div>
													</form>
												</div>
											
									<?php endif; ?>

												<!---- End Reply Ticket Display ---->

												<?php if($comments->isNotEmpty()): ?>

												<!---- Comments Display ---->

												<div class="card support-converbody">
													<div class="card-header border-0">
														<h4 class="card-title"><?php echo e(trans('langconvert.admindashboard.conversions')); ?></h4>
													</div>
													<div id="spruko_loaddata">

														<?php echo $__env->make('user.ticket.showticketdata', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

													</div>
												</div>

												<!--- End Comments Display -->
													<?php endif; ?>

											</div>
										</div>
									</div>
								</div>
							</section>
							<!--Ticket Show-->

							<?php $__env->stopSection(); ?>

		<?php $__env->startSection('scripts'); ?>


		<!-- INTERNAL Vertical-scroll js-->
		<script src="<?php echo e(asset('assets/plugins/vertical-scroll/jquery.bootstrap.newsbox.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Summernote js  -->
		<script src="<?php echo e(asset('assets/plugins/summernote/summernote.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL Index js-->
		<script src="<?php echo e(asset('assets/js/support/support-ticketview.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- INTERNAL DropZone js-->
		<script src="<?php echo e(asset('assets/plugins/dropzone/dropzone.js')); ?>?v=<?php echo time(); ?>"></script>

		<!-- GALLERY JS -->
		<script src="<?php echo e(asset('assets/plugins/simplelightbox/simplelightbox.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/simplelightbox/light-box.js')); ?>?v=<?php echo time(); ?>"></script>

		<!--Showmore Js-->
		<script src="<?php echo e(asset('assets/js/jquery.showmore.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/jquerysticky/jquery-sticky/jquery-sticky.js')); ?>?v=<?php echo time(); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/jquerysticky/jquery-sticky.js')); ?>?v=<?php echo time(); ?>"></script>

		<script type="text/javascript">
            "use strict";
			
			(function($){

				// Delete Media
				$('body').on('click', '.imgdel', function () {
					var product_id = $('.imgdel').data("id");
					swal({
						title: `<?php echo e(trans('langconvert.admindashboard.wanttocontinue')); ?>`,
						text: "<?php echo e(trans('langconvert.admindashboard.eraserecordspermanently')); ?>",
						icon: "warning",
						buttons: true,
						dangerMode: true,
					})
					.then((willDelete) => {
						if (willDelete) {
							$.ajax({
								type: "DELETE",
								url: SITEURL + "/customer/image/delete/"+product_id,
								success: function (data) {
									//  table.draw();
									$('#imageremove'+ product_id).remove();
								},
								data: {
								"_token": "<?php echo e(csrf_token()); ?>",

								},
								error: function (data) {
									console.log('Error:', data);
								}
							});
						}
					});			
				});
			})(jQuery);


			<?php if(setting('USER_FILE_UPLOAD_ENABLE') == 'yes'): ?>

			// Image Upload
			var uploadedDocumentMap = {}
			Dropzone.options.documentDropzone = {
				url: '<?php echo e(route('client.ticket.image' ,$ticket->ticket_id)); ?>',
				maxFilesize: '<?php echo e(setting('FILE_UPLOAD_MAX')); ?>', // MB
				addRemoveLinks: true,
				acceptedFiles: '<?php echo e(setting('FILE_UPLOAD_TYPES')); ?>',
				maxFiles: '<?php echo e(setting('MAX_FILE_UPLOAD')); ?>',
				headers: {
						'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
				},
				success: function (file, response) {
					$('form').append('<input type="hidden" name="comments[]" value="' + response.name + '">')
					uploadedDocumentMap[file.name] = response.name
				},
				removedfile: function (file) {
					file.previewElement.remove()
					var name = ''
					if (typeof file.file_name !== 'undefined') {
						name = file.file_name
					} else {
						name = uploadedDocumentMap[file.name]
					}
					$('form').find('input[name="comments[]"][value="' + name + '"]').remove()
				},
				init: function () {
					<?php if(isset($project) && $project->document): ?>
					var files =
					<?php echo json_encode($project->document); ?>

					for (var i in files) {
						var file = files[i]
						this.options.addedfile.call(this, file)
						file.previewElement.classList.add('dz-complete')
							$('form').append('<input type="hidden" name="comments[]" value="' + file.file_name + '">')
					}
					<?php endif; ?>
					this.on('error', function(file, errorMessage) {
						if (errorMessage.message) {
								var errorDisplay = document.querySelectorAll('[data-dz-errormessage]');
								errorDisplay[errorDisplay.length - 1].innerHTML = errorMessage.message;
						}
					});
				}
			}

			<?php endif; ?>

			// Scrolling Effect
			var page = 1;
			$(window).scroll(function() {
				if($(window).scrollTop() + $(window).height() >= $(document).height()) {
					page++;
					loadMoreData(page);
				}
			});

			function loadMoreData(page){
				$.ajax(
				{
					url: '?page=' + page,
					type: "get",
					
				})
				.done(function(data)
				{
					$("#spruko_loaddata").append(data.html);
				})
				.fail(function(jqXHR, ajaxOptions, thrownError)
				{
					alert('server not responding...');
				});
			}

			// Edit Form
			function showEditForm(id) {
				var x = document.querySelector(`#supportnote-icon-${id}`);

				if (x.style.display == "block") {
					x.style.display = "none";
				}
				else {

					x.style.display = "block";
				}
			}

			// Readmore
			let readMore = document.querySelectorAll('.readmores')
			readMore.forEach(( element, index)=>{
				if(element.clientHeight <= 200)    {
					element.children[0].classList.add('end')
				}
				else{
					element.children[0].classList.add('readMore')
				}
			})

			$(`.readMore`).showmore({
				closedHeight: 60,
				buttonTextMore: 'Read More',
				buttonTextLess: 'Read Less',
				buttonCssClass: 'showmore-button',
				animationSpeed: 0.5
			});

		</script>

		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.usermaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\uhelp\resources\views/user/ticket/showticket.blade.php ENDPATH**/ ?>