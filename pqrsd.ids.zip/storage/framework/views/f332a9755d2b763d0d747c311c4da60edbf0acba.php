

		<?php $__env->startSection('styles'); ?>

		<!-- INTERNAl Summernote css -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/summernote/summernote.css')); ?>?v=<?php echo time(); ?>">

		<!-- INTERNAL Data table css -->
		<link href="<?php echo e(asset('assets/plugins/datatable/css/dataTables.bootstrap5.min.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />
		<link href="<?php echo e(asset('assets/plugins/datatable/responsive.bootstrap5.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />

		<!-- INTERNAL Sweet-Alert css -->
		<link href="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert.css')); ?>?v=<?php echo time(); ?>" rel="stylesheet" />	
		<?php $__env->stopSection(); ?>

							<?php $__env->startSection('content'); ?>

							<!--Page header-->
							<div class="page-header d-xl-flex d-block">
								<div class="page-leftheader">
									<h4 class="page-title"><span class="font-weight-normal text-muted ms-2"><?php echo e(trans('langconvert.menu.faq')); ?></span></h4>
								</div>
							</div>
							<!--End Page header-->

							<div class="col-xl-12 col-lg-12 col-md-12">
								<div class="card ">
									<form method="POST" action="<?php echo e(url('/admin/faq')); ?>" enctype="multipart/form-data">
										<?php echo csrf_field(); ?>

										<?php echo view('honeypot::honeypotFormFields'); ?>

										<div class="card-header border-0 d-sm-max-flex">
											<h4 class="card-title"><?php echo e(trans('langconvert.admindashboard.faqsection')); ?></h4>
											<div class="card-options card-header-styles mt-sm-max-2">
												<small class="me-1 mt-1"><?php echo e(trans('langconvert.admindashboard.sectionhide')); ?></small>
												<div class="float-end mt-0">
													<div class="switch-toggle">
														<a class="onoffswitch2">
															<input type="checkbox"  name="faqcheck" id="faqchecks" class=" toggle-class onoffswitch2-checkbox" value="on" <?php if($basic->faqcheck == 'on'): ?>  checked=""  <?php endif; ?>>
															<label for="faqchecks" class="toggle-class onoffswitch2-label" ></label>
														</a>
													</div>
												</div>
											</div>
										</div>
										<div class="card-body" >
											<div class="row">
												<div class="col-sm-12 col-md-12">
													<input type="hidden" class="form-control " id="testimonial_id" name="id" value="<?php echo e($basic->id); ?>">
													<div class="form-group">
														<label class="form-label"><?php echo e(trans('langconvert.admindashboard.title')); ?> <span class="text-red">*</span></label>
														<input type="text" class="form-control <?php $__errorArgs = ['faqtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="faqtitle" value="<?php echo e($basic->faqtitle); ?>">
														<?php $__errorArgs = ['faqtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

													</div>
												</div>
												<div class="col-sm-12 col-md-12">
													<div class="form-group">
														<label class="form-label"><?php echo e(trans('langconvert.admindashboard.subtitle')); ?></label>
														<input type="text" class="form-control <?php $__errorArgs = ['faqsub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="faqsub" value="<?php echo e($basic->faqsub); ?>">
														<?php $__errorArgs = ['faqsub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

															<span class="invalid-feedback" role="alert">
																<strong><?php echo e($message); ?></strong>
															</span>
														<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

													</div>
												</div>
											</div>
										</div>
										<div class="col-md-12 card-footer ">
											<div class="form-group float-end">
												<input type="submit" class="btn btn-secondary" value="<?php echo e(trans('langconvert.admindashboard.savechanges')); ?>" onclick="this.disabled=true;this.form.submit();">
											</div>
										</div>
									</form>
								</div>
							</div>

							<div class="col-xl-12 col-lg-12 col-md-12">
								<div class="card ">
									<div class="card-header border-0 d-sm-max-flex">
										<h4 class="card-title"><?php echo e(trans('langconvert.menu.faq')); ?></h4>
										<div class="card-options mt-sm-max-2">
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FAQs Create')): ?>

											<a href="javascript:void(0)" class="btn btn-secondary me-3" id="create-new-post" onclick="addPost()"><?php echo e(trans('langconvert.admindashboard.addfaq')); ?></a>
											<?php endif; ?>

										</div>
									</div>
									<div class="card-body" >
										<div class="table-responsive spruko-delete">
											<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FAQs Delete')): ?>

											<button id="massdeletenotify" class="btn btn-outline-light btn-sm mb-4 data-table-btn"><i class="fe fe-trash"></i> <?php echo e(trans('langconvert.admindashboard.delete')); ?></button>
											<?php endif; ?>

											<table class="table table-vcenter text-nowrap table-bordered table-striped ticketdeleterow w-100" id="support-articlelists">
												<thead>
													<tr>
														<th  width="10"><?php echo e(trans('langconvert.admindashboard.id')); ?></th>
														<th  width="10"><?php echo e(trans('langconvert.admindashboard.slNo')); ?></th>
														<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('FAQs Delete')): ?>

														<th width="10" >
															<input type="checkbox"  id="customCheckAll">
															<label  for="customCheckAll"></label>
														</th>
														<?php endif; ?>
														<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('FAQs Delete')): ?>

														<th width="10" >
															<input type="checkbox"  id="customCheckAll" disabled>
															<label  for="customCheckAll"></label>
														</th>
														<?php endif; ?>

														<th ><?php echo e(trans('langconvert.admindashboard.question')); ?></th>
														<th ><?php echo e(trans('langconvert.admindashboard.answer')); ?></th>
														<th ><?php echo e(trans('uhelpupdate::langconvert.newwordslang.privatemode')); ?></th>
														<th class="w-5"><?php echo e(trans('langconvert.admindashboard.status')); ?></th>
														<th class="w-5"><?php echo e(trans('langconvert.admindashboard.actions')); ?></th>
													</tr>
												</thead>
												<tbody>
													
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
							<?php $__env->stopSection(); ?>
	<?php $__env->startSection('modal'); ?>

   	<?php echo $__env->make('admin.faq.model', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php $__env->stopSection(); ?>

		<?php $__env->startSection('scripts'); ?>

		<!-- INTERNAL Vertical-scroll js-->
		<script src="<?php echo e(asset('assets/plugins/vertical-scroll/jquery.bootstrap.newsbox.js')); ?>"></script>

		<!-- INTERNAL Summernote js  -->
		<script src="<?php echo e(asset('assets/plugins/summernote/summernote.js')); ?>"></script>

		<!-- INTERNAL Data tables -->
		<script src="<?php echo e(asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/datatable/js/dataTables.bootstrap5.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/datatable/responsive.bootstrap5.min.js')); ?>"></script>

		<!-- INTERNAL Index js-->
		<script src="<?php echo e(asset('assets/js/support/support-sidemenu.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/js/support/support-articles.js')); ?>"></script>

		<!-- INTERNAL Sweet-Alert js-->
		<script src="<?php echo e(asset('assets/plugins/sweet-alert/sweetalert.min.js')); ?>"></script>

		<script type="text/javascript">

			"use strict";
			
			(function($)  {

				// Variables
				var SITEURL = '<?php echo e(url('')); ?>';

				// Csrf Field
				$.ajaxSetup({
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					}
				});

				// Datatable
				$('#support-articlelists').DataTable({
					processing: true,
					serverSide: true,
					ajax: {
						url: "<?php echo e(route('faq.index')); ?>"
					},
					columns: [
						{data: 'id', name: 'id', 'visible': false},
						{data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false,searchable: false},
						{data: 'checkbox', name: 'checkbox', orderable: false,searchable: false},
						{data: 'question', name: 'question' },
						{data: 'answer', name: 'answer' },
						{ data: 'privatemode', name: 'privatemode' },
						{ data: 'status', name: 'status' },
						{data: 'action', name: 'action', orderable: false},
					],
					order:[],
					responsive: true,
					drawCallback: function () {
						var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
						var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
							return new bootstrap.Tooltip(tooltipTriggerEl)
						});
						$('.form-select').select2({
							minimumResultsForSearch: Infinity,
							width: '100%'
						});
						$('#customCheckAll').prop('checked', false);

						$('.checkall').on('click', function(){
							if($('.checkall:checked').length == $('.checkall').length){
								$('#customCheckAll').prop('checked', true);
							}else{
								$('#customCheckAll').prop('checked', false);
							}
						});
					},
				});

				//Mass Delete 
				$('body').on('click', '#massdeletenotify', function () {
					var id = [];
					$('.checkall:checked').each(function(){
						id.push($(this).val());
					});
					if(id.length > 0){
						swal({
							title: `<?php echo e(trans('langconvert.admindashboard.wanttocontinue')); ?>`,
							text: "<?php echo e(trans('langconvert.admindashboard.eraserecordspermanently')); ?>",
							icon: "warning",
							buttons: true,
							dangerMode: true,
						})
						.then((willDelete) => {
							if (willDelete) {
								$.ajax({
									url:"<?php echo e(route('faq.deleteall')); ?>",
									method:"post",
									data:{id:id},
									success:function(data)
									{
										$('#support-articlelists').DataTable().ajax.reload();
										toastr.error(data.error);
													
									},
									error:function(data){
										console.log(data);
									}
								});
							}
						});				
					}else{
						toastr.error('<?php echo e(trans('langconvert.functions.checkboxselect')); ?>');
					}

				});
				//Mass Delete

				// checkbox check all
				$('#customCheckAll').on('click', function() {
					$('.checkall').prop('checked', this.checked);
				});

				// Status change faq
				$('body').on('click', '.tswitch', function () {
					var _id = $(this).data("id");
					var status = $(this).prop('checked') == true ? '1' : '0';
					$.ajax({
						type: "post",
						url: SITEURL + "/admin/faq/status"+_id,
						data: {'status': status},
						success: function (data) {
							toastr.success(data.success);
						},
						error: function (data) {
							console.log('Error:', data);
						}
					});
				});

				// privatemode change faq
				$('body').on('click', '.tswitch1', function () {
					var _id = $(this).data("id");
					var privatemode = $(this).prop('checked') == true ? '1' : '0';
					$.ajax({
						type: "post",
						url: SITEURL + "/admin/faq/privatestatus/"+_id,
						data: {'privatemode': privatemode},
						success: function (data) {
							toastr.success(data.success);
						},
						error: function (data) {
							console.log('Error:', data);
						}
					});
				});

			})(jQuery);

			// Add faq
			function addPost() {
                $("#faq_id").val('');
                $(".modal-title").text('<?php echo e(trans('langconvert.admindashboard.addnewfaq')); ?>');
				$('#faq_form').trigger("reset");
				$('#answer').summernote('reset');
                $('#addfaq').modal('show');
            }
			
			// edit faq
            function editPost(event) {
                var id  = $(event).data("id");
                let _url = `<?php echo e(url('/admin/faq/${id}')); ?>`;
                $('#questionError').text('');
                $('#answerError').text('');
                $.ajax({
                	url: _url,
               		type: "GET",
                	success: function(response) {
                    	if(response) {
							$('#questionError').text('');
                			$('#answerError').text('');
                     	   	$(".modal-title").text('<?php echo e(trans('langconvert.admindashboard.editfaq')); ?>');
                        	$("#faq_id").val(response.id);
                        	$("#question").val(response.question);
                        	$("#answer").summernote('code',response.answer);
							if (response.status == "1")
							{
								$('#status').prop('checked', true);
							}
							if (response.privatemode == "1")
							{
								$('#privatemode').prop('checked', true);
							}
                        	$('#addfaq').modal('show');
                   		}
                	}
                });
            }

			// Delete faq
            function deletePost(event) {
                var id  = $(event).data("id");
                let _url = `<?php echo e(url('/admin/faq/delete/${id}')); ?>`;
                let _token   = $('meta[name="csrf-token"]').attr('content');
				swal({
					title: `<?php echo e(trans('langconvert.admindashboard.wanttocontinue')); ?>`,
					text: "<?php echo e(trans('langconvert.admindashboard.eraserecordspermanently')); ?>",
					icon: "warning",
					buttons: true,
					dangerMode: true,
				})
				.then((willDelete) => {
					if (willDelete) {
						$.ajax({
							url: _url,
							type: 'DELETE',
							data: {
								_token: _token
							},
							success: function(response) {
								toastr.error(response.error);
								var oTable = $('#support-articlelists').dataTable();
								oTable.fnDraw(false);
							},
							error: function (data) {
								console.log('Error:', data);
							}
						});
					}
				});
            }

			// create the faq
            function createPost() {
				$('#questionError').text('');
                $('#answerError').text('');
                var question = $('#question').val();
                var answer = $('#answer').val();
				var status = $('#status').prop('checked') == true ? '1' : '0';
				var privatemode = $('#privatemode').prop('checked') == true ? '1' : '0';
                var id = $('#faq_id').val();
				var actionType = $('#btnsave').val();
				var fewSeconds = 2;
				$('#btnsave').prop('disabled', true);
					setTimeout(function(){
						$('#btnsave').prop('disabled', false);
					}, fewSeconds*1000);
                let _url = `<?php echo e(url('/admin/faq/create')); ?>`;
                let _token   = $('meta[name="csrf-token"]').attr('content');
                $.ajax({
                    url:_url,
                    type:"POST",
                    data:{
                        id: id,
                        question: question,
                        answer: answer,
                        status: status,
                        privatemode: privatemode,
                        _token: _token
                    },
                    success: function(response) {
                        if(response.code == 200) {
							$('#questionError').text('');
                			$('#answerError').text('');
							$('#faq_form').trigger("reset");
							$('#answer').summernote('reset');
							$('#addfaq').modal('hide');
                            var oTable = $('#support-articlelists').dataTable();
							oTable.fnDraw(false);
                            toastr.success(response.success);

                        }
                    },
                    error: function(response) {
						$('#questionError').text('');
                		$('#answerError').text('');
                        $('#questionError').text(response.responseJSON.errors.question);
                        $('#answerError').text(response.responseJSON.errors.answer);
                    }
                });

            }

			// cancel faq
			function cancelPost() {
				$('#faq_form').trigger("reset");
				$('#answer').summernote('reset');
			}
		
		</script>

		<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\uhelp\resources\views/admin/faq/index.blade.php ENDPATH**/ ?>